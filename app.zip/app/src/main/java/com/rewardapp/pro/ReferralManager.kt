
package com.rewardapp.pro

object ReferralManager {

    fun generate(uid: String): String {
        return uid.take(6).uppercase()
    }
}
