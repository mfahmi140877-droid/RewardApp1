
package com.rewardapp.pro

object AntiCheat {

    private var lastClick = 0L

    fun isSafe(): Boolean {
        return !isRooted() &&
                !isEmulator() &&
                !isSpamClick()
    }

    private fun isSpamClick(): Boolean {
        val now = System.currentTimeMillis()

        if (now - lastClick < 3000) {
            return true
        }

        lastClick = now
        return false
    }

    private fun isRooted(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su"
        )

        return paths.any {
            java.io.File(it).exists()
        }
    }

    private fun isEmulator(): Boolean {
        return android.os.Build.FINGERPRINT.contains("generic")
    }
}
