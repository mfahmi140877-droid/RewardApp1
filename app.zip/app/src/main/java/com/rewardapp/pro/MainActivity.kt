
package com.rewardapp.pro

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {

    private var rewardedAd: RewardedAd? = null
    private lateinit var balanceText: TextView
    private var balance = 0

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseDatabase.getInstance().reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this)

        balanceText = findViewById(R.id.balanceText)
        val watchBtn = findViewById<Button>(R.id.watchBtn)
        val dailyBtn = findViewById<Button>(R.id.dailyBtn)

        anonymousLogin()

        loadRewarded()

        watchBtn.setOnClickListener {
            if (!AntiCheat.isSafe()) return@setOnClickListener

            rewardedAd?.show(this) {
                balance += 10
                updateBalance()
            }
        }

        dailyBtn.setOnClickListener {
            balance += 5
            updateBalance()
        }
    }

    private fun anonymousLogin() {
        auth.signInAnonymously()
    }

    private fun updateBalance() {
        balanceText.text = "Coins: $balance"

        auth.currentUser?.uid?.let {
            db.child("users")
                .child(it)
                .child("coins")
                .setValue(balance)
        }
    }

    private fun loadRewarded() {
        val request = AdRequest.Builder().build()

        RewardedAd.load(
            this,
            "ca-app-pub-3940256099942544/5224354917",
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
            }
        )
    }
}
