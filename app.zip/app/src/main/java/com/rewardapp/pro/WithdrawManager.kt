
package com.rewardapp.pro

data class WithdrawRequest(
    val uid: String = "",
    val amount: Int = 0,
    val method: String = "",
    val account: String = ""
)
